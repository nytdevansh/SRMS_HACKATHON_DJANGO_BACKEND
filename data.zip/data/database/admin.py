from django.contrib import admin

# Register your models here.


from .models import Locations
admin.site.register(Locations)